﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebZendesk
{
    public partial class Account_Unlock : System.Web.UI.Page
    {
        log4net.ILog Logging = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
        }
        protected void btnUnlock_Click(object sender, EventArgs e)
        {
            try
            {
                Common_Utility Utility = new Common_Utility();
                string sUsername, semail, sOTP, sIslocked, semailfromDB;
                sUsername = txtUname.Text;
                semail = txtEmail.Text;
                semailfromDB = Utility.RetrieveUser(sUsername, "Email");
                if (semail == semailfromDB)
                {

                    sIslocked = Utility.RetrieveUser(sUsername, "IsUserLocked");
                    if (sIslocked != "Y")
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Account is not Locked'); window.location.href = 'Login.aspx'", true);
                        return;
                    }
                    else
                    {

                        sOTP = Utility.RandomNumberGeneration().ToString();
                        Utility.UpdateUser(sUsername, new Dictionary<string, string> { { "OTP", sOTP } });
                        Utility.Emailing(sOTP, semail, "Account Unlock - Account Unlock");
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('OTP has been Sent to yor Email.Please check and validate');", true);
                        //Response.Write("<script>alert('OTP has been Sent to yor Email.Please check and validate ');</script>");
                        //Response.Clear();
                        divunlock.Visible = false;
                        divOTP.Visible = true;
                    }
                }
                else
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Invalid Username or Email');", true);

                    //Response.Write("<script>alert('Invalid Username or Email');</script>");
                    //Response.Clear();
                }
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
        }
        protected void btnValidate_Click(object sender, EventArgs e)
        {
            try
            {
                string sOTP = txtOTP.Text;
                string sUsername = txtUname.Text;
                Common_Utility Utility = new Common_Utility();
                string strOTPfromDB = Utility.RetrieveUser(sUsername, "OTP");
                if (sOTP != strOTPfromDB)
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Invalid OTP Entered');", true);
                    //Response.Write("<script>alert('Invalid OTP Entered');</script>");
                    //Response.Clear();

                }
                else
                {

                    Utility.UpdateUser(sUsername, new Dictionary<string, string> {
            { "MaxAttempts", string.Empty }, 
            { "IsUserLocked", string.Empty }, 
            { "MaxOTPAttempts", string.Empty } });

                    // Response.Write("<script>alert('Account Unlocked Successfully!');</script>");
                    //  Response.Clear();
                    divOTP.Visible = false;
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Account Unlocked Successfully'); window.location.href = 'Login.aspx'", true);


                    // Response.Redirect("Login.aspx");
                }
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtUname.Text = string.Empty;
            txtEmail.Text = string.Empty;
        }
    }
}
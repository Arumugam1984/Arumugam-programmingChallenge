﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
//[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace WebZendesk
{
    public partial class User_Registration : System.Web.UI.Page
    {
        log4net.ILog Logging = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        Common_Utility utility = new Common_Utility();
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
        }
        protected void btnRegister_Click(object sender, EventArgs e)
        {
            try
            {
                string sName, sUsername, sPwd, sEmail;
                sUsername = txtUsername.Text;
                sName = txtName.Text;
                sEmail = txtEmail.Text.ToLower();

                //Check for known Passwords
                if (KnownpwdCheck(txtPassword.Text))
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('This is known Passowrd. Please try with another Password');", true);
                    return;
                }
                else
                {
                    //Using SHA256 Hashing
                    sPwd = utility.Sha256Hashing(txtPassword.Text);

                    utility.RegisterUser(sName, sUsername, sPwd, sEmail);
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('User Registration Successful'); window.location.href = 'Login.aspx'", true);

                }


            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
        }

        public bool KnownpwdCheck(string sPassword)
        {
            try
            {
                string sPwdFile = Server.MapPath("KnownPasswords.txt");
                string[] sKnownpwds = File.ReadAllLines(sPwdFile);
                return sKnownpwds.Contains(sPassword);
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return true;
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            txtName.Text = string.Empty;
            txtUsername.Text = string.Empty;
            txtPassword.Text = string.Empty;
            txtConfirmPwd.Text = string.Empty;
            // txtEmail.Text = string.Empty;
        }
    }
}
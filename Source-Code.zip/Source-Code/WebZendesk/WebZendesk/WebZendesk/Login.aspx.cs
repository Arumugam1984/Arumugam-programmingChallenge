﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebZendesk
{
    public partial class Login : System.Web.UI.Page
    {
        log4net.ILog logging = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Session.Abandon();
            }
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.Cache.SetExpires(DateTime.Now.AddSeconds(-1));
            Response.Cache.SetNoStore();
        }
        protected void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {

                Common_Utility Utility = new Common_Utility();
                string sUsername, sPwd, sToemail, sOTP;
                sUsername = txtUname.Text;
                sPwd = txtPwd.Text;

                //Check to see If user Accont locked
                string IsAccountLocked = Utility.RetrieveUser(sUsername, "IsUserLocked");
                if (IsAccountLocked == "Y")
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Account locked, Please activate your account'); window.location.href = 'Account_Unlock.aspx'", true);

                }

                if (Utility.ValidateUser(sUsername, sPwd))
                {

                    Session["uname"] = sUsername;
                    divLogin.Visible = false;
                    sOTP = Utility.RandomNumberGeneration().ToString();
                    Utility.UpdateUser(sUsername, new Dictionary<string, string> {
            { "OTP", sOTP }});
                    sToemail = Utility.RetrieveUser(sUsername, "Email");
                    Utility.Emailing(sOTP, sToemail, "Login - OTP");
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('OTP has been Sent to yor Email.Please check and validate');", true);

                    divOTP.Visible = true;
                }
                else
                {
                    if (Utility.LockUserAccount(sUsername))
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Your Account has been Locked due to maximum attempts reached'); window.location.href = 'Account_Unlock.aspx'", true);

                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Invalid User credentials');", true);

                    }
                }
            }

            catch (Exception ex)
            {

                logging.Error(ex);
                Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Mail not sent successfully-Redirecting to Login'); window.location.href = 'Login.aspx'", true);
            }
        }
        protected void btnLoginagain_Click(object sender, EventArgs e)
        {
            try
            {
                string sOTP = txtOTP.Text;

                Common_Utility Utility = new Common_Utility();
                string IsAccountLocked = Utility.RetrieveUser(Session["uname"].ToString(), "IsUserLocked");
                if (IsAccountLocked == "Y")
                {
                    Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Account locked, Please activate your account'); window.location.href = 'Account_Unlock.aspx'", true);

                }

                string strOTPfromDB = Utility.RetrieveUser(Session["uname"].ToString(), "OTP");
                if (sOTP != strOTPfromDB)
                {
                    if (Utility.LockUserAccountForOTP(Session["uname"].ToString()))
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Your Account has been Locked due to maximum attempts reached'); window.location.href = 'Account_Unlock.aspx'", true);

                    }
                    else
                    {
                        Page.ClientScript.RegisterStartupScript(this.GetType(), "ButtonClickEventScript", "alert('Invalid OTP Entered');", true);

                    }
                }
                else
                {

                    Utility.UpdateUser(Session["uname"].ToString(), new Dictionary<string, string> {
            { "MaxAttempts", string.Empty }, 
            { "IsUserLocked", string.Empty }, 
            { "MaxOTPAttempts", string.Empty } });

                    Response.Redirect("User_Home.aspx");

                }

            }
            catch (Exception ex)
            {
                logging.Error(ex);
            }

        }
    }
}
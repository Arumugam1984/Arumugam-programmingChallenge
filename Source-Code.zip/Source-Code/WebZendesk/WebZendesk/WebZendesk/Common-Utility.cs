﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using System.Net;
using System.Net.Mail;
using System.Web.Configuration;
using System.Web.UI;
[assembly: log4net.Config.XmlConfigurator(Watch = true)]

namespace WebZendesk
{
    public class Common_Utility
    {
        public Common_Utility()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        log4net.ILog Logging = log4net.LogManager.GetLogger(System.Reflection.MethodBase.GetCurrentMethod().DeclaringType);

        public string Sha256Hashing(string sData)
        {
            StringBuilder sBuilder = new StringBuilder();
            try
            {
                using (SHA256 sha256Hashing = SHA256.Create())
                {
                    byte[] bytes = sha256Hashing.ComputeHash(Encoding.UTF8.GetBytes(sData));
                   
                    for (int i = 0; i < bytes.Length; i++)
                    {
                        sBuilder.Append(bytes[i].ToString("x2"));
                    }
                    
                }
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return sBuilder.ToString();
        }

        public bool ValidateUser(string sUsername, string sPassword)
        {
            
            string sFilename = System.Web.HttpContext.Current.Server.MapPath("DB.xml");

            XmlDocument xml = new XmlDocument();
            try
            {
                string sHashpwd = Sha256Hashing(sPassword);
                xml.Load(sFilename);
                XmlNodeList xmList = xml.SelectNodes("Users/User[@Username='" + sUsername + "']");
                if (xmList == null || xmList.Count <= 0)
                {
                    return false;
                }
                foreach (XmlNode xnode in xmList)
                {
                    foreach (XmlNode xchild in xnode.ChildNodes)
                    {

                        if (xchild.Name == "PWD")
                        {
                            if (sHashpwd != xchild.InnerText)
                            {
                                return false;
                            }
                        }
                    }
                }

                
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return true;
        }

        public string RegisterUser(string sName, string sUsername, string sPassword, string sEmail)
        {
            try
            {
                string sFilename = System.Web.HttpContext.Current.Server.MapPath("DB.xml");
                XmlDocument xDoc = new XmlDocument();

                xDoc.Load(sFilename);

                XmlElement xElement = xDoc.CreateElement("User");
                xElement.SetAttribute("Username", sUsername);

                XmlNode N_Name = xDoc.CreateElement("Name");
                XmlNode N_Email = xDoc.CreateElement("Email");
                XmlNode N_PWD = xDoc.CreateElement("PWD");
                XmlNode N_MaxAttempts = xDoc.CreateElement("MaxAttempts");
                XmlNode N_IsUserLocked = xDoc.CreateElement("IsUserLocked");
                XmlNode N_LastLoginDateTime = xDoc.CreateElement("LastLoginDateTime");
                XmlNode N_OTP = xDoc.CreateElement("OTP");

                N_Name.InnerText = sName;
                N_Email.InnerText = sEmail;
                N_PWD.InnerText = sPassword;
                N_MaxAttempts.InnerText = string.Empty;
                N_IsUserLocked.InnerText = string.Empty;
                N_LastLoginDateTime.InnerText = System.DateTime.Today.ToShortDateString();
                N_OTP.InnerText = string.Empty;

                //Adding in Parent node

                xElement.AppendChild(N_Name);
                xElement.AppendChild(N_Email);
                xElement.AppendChild(N_PWD);
                xElement.AppendChild(N_MaxAttempts);
                xElement.AppendChild(N_IsUserLocked);
                xElement.AppendChild(N_LastLoginDateTime);
                xElement.AppendChild(N_OTP);

                xDoc.DocumentElement.AppendChild(xElement);
                xDoc.Save(sFilename);
                return string.Empty;
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
                throw ;
            }


        }

        

        public Boolean UpdateUser(string sUsername, Dictionary<string, string> UpdateAttributes)
        {
            XmlDataDocument xml = new XmlDataDocument();
            try
            {

                xml.Load(System.Web.HttpContext.Current.Server.MapPath("DB.xml"));
                XmlNodeList xList = xml.SelectNodes("/Users/User[@Username='" + sUsername + "']");
                if (xList == null || xList.Count <= 0)
                {
                    return false;
                }
                foreach (XmlNode xn in xList)
                {
                    foreach (XmlNode xcn in xn.ChildNodes)
                    {
                        foreach (var x in UpdateAttributes)
                        {
                            if (xcn.Name == x.Key)
                            {
                                xcn.InnerText = x.Value;
                            }
                        }
                    }
                }
                
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }

            xml.Save(System.Web.HttpContext.Current.Server.MapPath("DB.xml"));
            return true;
        }

        public string RandomNumberGeneration()
        {
            RNGCryptoServiceProvider cprovider = new RNGCryptoServiceProvider();
            var byteArray = new byte[4];
            var OTP = UInt32.MinValue;
            try
            {
                cprovider.GetBytes(byteArray);

                // conver 4 bytes to an integer
                OTP = BitConverter.ToUInt32(byteArray, 0);
                
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return OTP.ToString();
        }

        public void Emailing(string sBodydata, string stoEmail, string sSubject)
        {
            try
            {
                MailMessage mail = new MailMessage();
               
                string sUname, sFromaddress, sToaddress, sPwd;
                SmtpClient smtpserver = new System.Net.Mail.SmtpClient(System.Configuration.ConfigurationManager.AppSettings["SMTPServer"]);
                smtpserver.Port = 587;
                sUname = WebConfigurationManager.AppSettings["Username"];
                sPwd = WebConfigurationManager.AppSettings["Pwd"];
                sFromaddress = WebConfigurationManager.AppSettings["FromEmail"];
                sToaddress = stoEmail;

                mail.From = new MailAddress(sFromaddress);
                mail.To.Add(sToaddress);
                mail.Subject = sSubject;
                mail.Body = sBodydata;

                smtpserver.Credentials = new System.Net.NetworkCredential(sUname, sPwd);
                smtpserver.EnableSsl = true;
                smtpserver.Send(mail);
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
                throw ;
            }


        }

        public Boolean LockUserAccount(string Username)
        {
            XmlDocument xml = new XmlDocument();
            try
            {
                xml.Load(System.Web.HttpContext.Current.Server.MapPath("DB.xml"));
                int imaxAttempts = 0;
                XmlNodeList xnList = xml.SelectNodes("/Users/User[@Username='" + Username + "']");
                if (xnList == null || xnList.Count <= 0)
                {
                    return false;
                }
                foreach (XmlNode xn in xnList)
                {
                    foreach (XmlNode xcn in xn.ChildNodes)
                    {
                        if (xcn.Name == "MaxAttempts")
                        {
                            imaxAttempts = !string.IsNullOrEmpty(xcn.InnerText) ? Convert.ToInt32(xcn.InnerText) : 0;

                        }
                    }
                }
                int imaxAttemptsConfigured = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["maxLoginAttempts"]);
                if (imaxAttempts < imaxAttemptsConfigured)
                {
                    UpdateUser(Username, new Dictionary<string, string> { { "MaxAttempts", (imaxAttempts + 1).ToString() } });

                    if (imaxAttempts + 1 == imaxAttemptsConfigured)
                        UpdateUser(Username, new Dictionary<string, string> { { "IsUserLocked", "Y" } });

                    return false;
                }
                
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return true;
        }

        public Boolean LockUserAccountForOTP(string Username)
        {
            XmlDocument xml = new XmlDocument();
            try
            {
                xml.Load(System.Web.HttpContext.Current.Server.MapPath("DB.xml"));
                int imaxAttempts = 0;
                XmlNodeList xnList = xml.SelectNodes("/Users/User[@Username='" + Username + "']");
                if (xnList == null || xnList.Count <= 0)
                {
                    return false;
                }
                foreach (XmlNode xn in xnList)
                {
                    foreach (XmlNode xcn in xn.ChildNodes)
                    {
                        if (xcn.Name == "MaxOTPAttempts")
                        {
                            imaxAttempts = !string.IsNullOrEmpty(xcn.InnerText) ? Convert.ToInt32(xcn.InnerText) : 0;

                        }
                    }
                }
                int imaxAttemptsConfigured = Convert.ToInt32(System.Configuration.ConfigurationManager.AppSettings["maxLoginAttempts"]);
                if (imaxAttempts < imaxAttemptsConfigured)
                {
                    UpdateUser(Username, new Dictionary<string, string> {
            { "MaxOTPAttempts", (imaxAttempts + 1).ToString() }});

                    if (imaxAttempts + 1 == imaxAttemptsConfigured)
                        UpdateUser(Username, new Dictionary<string, string> {
            { "IsUserLocked", "Y" }});

                    return false;
                }
              
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return true;

        }

        public string RetrieveUser(string sUsername, string sAttributename)
        {
            XmlDataDocument xml = new XmlDataDocument();
            try
            {

                xml.Load(System.Web.HttpContext.Current.Server.MapPath("DB.xml"));
                XmlNodeList xList = xml.SelectNodes("/Users/User[@Username='" + sUsername + "']");
                if (xList == null || xList.Count <= 0)
                {
                    return string.Empty;
                }
                foreach (XmlNode xn in xList)
                {
                    foreach (XmlNode xcn in xn.ChildNodes)
                    {
                        if (xcn.Name == sAttributename)
                        {
                            return xcn.InnerText;
                        }
                    }
                }

                
            }
            catch (Exception ex)
            {
                Logging.Error(ex);
            }
            return string.Empty;
        }
    }
}